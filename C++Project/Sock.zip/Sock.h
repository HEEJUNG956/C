// Sock.h : main header file for the SOCK application
//

#if !defined(AFX_SOCK_H__E656E79E_C09F_42BC_A002_1C2032AA19DB__INCLUDED_)
#define AFX_SOCK_H__E656E79E_C09F_42BC_A002_1C2032AA19DB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CSockApp:
// See Sock.cpp for the implementation of this class
//

class CSockApp : public CWinApp
{
public:
	CSockApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSockApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CSockApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SOCK_H__E656E79E_C09F_42BC_A002_1C2032AA19DB__INCLUDED_)
